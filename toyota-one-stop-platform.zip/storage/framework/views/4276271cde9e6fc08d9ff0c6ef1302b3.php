<?php echo $__env->make('employee.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5 pt-5 pb-5 shadow bg-dark text-light px-5">
        <div class="row">
            <div class="col-12">
                <h3 class="display-5">
                    Hello <?php echo e(auth()->user()->name); ?>

                </h3>
                <p class="text-secondary fs-4">Welcome to Toyota team dashboard</p>
            </div>
        </div>
    </div>

    <div class="container shadow mt-5 bg-white py-5 px-5">
        <h3>Works assigned for you</h3>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <?php if($services->isEmpty()): ?>
                    <div class="alert alert-light">
                        No works assigned for you
                    </div>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Service</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img src="/storage/<?php echo e($service->car->photo); ?>" alt="<?php echo e($service->car->name); ?>"
                                            class="img-fluid"><br>
                                        <b><?php echo e($service->car->name); ?>: </b>
                                        <p><?php echo e($service->service_description); ?> </p>
                                        <b>Location: <?php echo e($service->location); ?></b>
                                        <p>
                                            <i class="bi bi-person-circle"></i> <?php echo e($service->user->name); ?><br>
                                            <i class="bi bi-telephone-fill"></i> <?php echo e($service->user->phone); ?>

                                        </p>
                                    </td>
                                    <td>
                                        <?php if($service->status): ?>
                                            <p class="text-success"><i class="bi bi-check"></i> Completed</p>
                                        <?php else: ?>
                                            <p class="text-warning"><i class="bi bi-clock-history"></i> Pending</p>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <!-- Button trigger modal -->
                                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                            data-bs-target="#exampleModal-<?php echo e($service->id); ?>">
                                            Mark as complete
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="exampleModal-<?php echo e($service->id); ?>" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Mark as complete
                                                        </h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        Are you sure you want to mark it as complete? Once changed it cannot
                                                        be undone!
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Cancel</button>
                                                        <form action="<?php echo e(route('employee.mark_complete', $service->id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <button type="submit" class="btn btn-primary">Yes</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mriganka/laravel/toyota-one-stop-platform/resources/views/employee/dashboard.blade.php ENDPATH**/ ?>