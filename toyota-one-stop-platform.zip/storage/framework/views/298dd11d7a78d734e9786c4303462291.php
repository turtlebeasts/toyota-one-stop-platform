<?php echo $__env->make('user.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-12">
                <div class="card shadow border-0">
                    <div class="card-body">
                        <h6 class="display-6">Appointments</h6>

                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('delete')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('delete')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($appointments->isEmpty()): ?>
                            <p class="text-center mt-5">You do not have any appointments</p>
                        <?php else: ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Appointment details</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($appointment->type == 1 ? 'Test Drive' : 'Service appointment'); ?><br>
                                                Vehicle: <?php echo e($appointment->car->name); ?><br>
                                                Date & Time: <?php echo e($appointment->date); ?> <?php echo e($appointment->time); ?><br>
                                                <img src="/storage/<?php echo e($appointment->car->photo); ?>"
                                                    alt="<?php echo e($appointment->car->name); ?>" class="img-fluid" width="250">
                                            </td>
                                            <td>
                                                <?php if($appointment->status): ?>
                                                    <p class="text-success">Approved / Completed</p>
                                                <?php else: ?>
                                                    <p class="text-warning">Pending</p>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <!-- Button trigger modal -->
                                                <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                                    data-bs-target="#delete-<?php echo e($appointment->id); ?>">
                                                    Cancel
                                                </button>
                                                <?php if($appointment->status): ?>
                                                    <p class="text-success">Scheduled at <b><?php echo e($appointment->date); ?>

                                                            <?php echo e($appointment->time); ?></b></p>
                                                <?php endif; ?>

                                                <!-- Modal -->
                                                <div class="modal fade" id="delete-<?php echo e($appointment->id); ?>" tabindex="-1"
                                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Cancel
                                                                </h1>
                                                                <button type="button" class="btn-close"
                                                                    data-bs-dismiss="modal" aria-label="Close"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p class="text-danger">Are you sure you want to cancel this
                                                                    appointment?</p><br>
                                                                <div class="alert alert-danger">
                                                                    <?php echo e($appointment->type == 1 ? 'Test Drive' : 'Service appointment'); ?><br>
                                                                    Vehicle: <?php echo e($appointment->car->name); ?><br>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                    data-bs-dismiss="modal">Close</button>
                                                                <form
                                                                    action="<?php echo e(route('appointment.destroy', $appointment->id)); ?>"
                                                                    method="post">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit"
                                                                        class="btn btn-danger">Confirm</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mriganka/laravel/toyota-one-stop-platform/resources/views/user/appointment.blade.php ENDPATH**/ ?>