<?php echo $__env->make('employee.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5 pt-5 pb-5 px-5">
        <div class="row">
            <div class="col-4"></div>
            <div class="col-sm-12 col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h6 class="text-danger">Change account password</h6>
                        <p class="text-danger">You can change your password for security reasons or reset it if you
                            forget it. Your Toyota Employee Account password is used to access the Employee dashboard, for
                            performing critical actions on this account, which may reflect on your work profile.</p>
                        <form action="<?php echo e(route('employee.set_password')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mt-3">
                                <label for="c_password" class="form-label">Current Password</label>
                                <input type="text" name="current_password" id="c_password" class="form-control">
                            </div>
                            <div class="mt-3">
                                <label for="password" class="form-label">New Password</label>
                                <input type="password" name="password" id="password" class="form-control">
                            </div>
                            <div class="mt-3">
                                <label for="password_confirmation" class="form-label">Confirm Password</label>
                                <input type="text" name="password_confirmation" id="password_confirmation"
                                    class="form-control">
                            </div>
                            <div class="mt-3">
                                <button type="submit" class="btn btn-danger">I confirm to change my password</button>
                            </div>
                            <?php if($errors->all()): ?>
                                <ul class="alert alert-danger mt-2">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                                <div class="alert alert-success mt-2">
                                    <?php echo e(session('success')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session('error')): ?>
                                <div class="alert alert-danger mt-2">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-4"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mriganka/laravel/toyota-one-stop-platform/resources/views/employee/password.blade.php ENDPATH**/ ?>