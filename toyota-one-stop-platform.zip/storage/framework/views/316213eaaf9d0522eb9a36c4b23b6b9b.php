<?php echo $__env->make('user.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5 pt-5 pb-5 shadow bg-white px-5">
        <div class="row">
            <div class="col-12">
                <h3>Applied services</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-4">
                <form action="<?php echo e(route('services.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="mt-3">
                        <label for="car_id">Select Vehicle</label>
                        <select name="car_id" id="car_id" class="form-control">
                            <option value="">-SELECT-</option>
                            <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($car->id); ?>"><?php echo e($car->name); ?> (<?php echo e($car->color); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mt-3">
                        <label for="service_description">Define your service</label>
                        <textarea name="service_description" id="service_description" cols="3" rows="3" class="form-control"></textarea>
                    </div>
                    <div class="mt-3">
                        <label for="location">Add the location</label>
                        <input type="text" name="location" id="location" class="form-control">
                    </div>
                    <div class="mt-3">
                        <label for="date">Date</label>
                        <input type="date" name="date" id="date" class="form-control">
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-dark">Submit</button>
                    </div>
                    <div class="mt-3">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session('delete')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('delete')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($errors->all()): ?>
                            <ul class="alert alert-danger mt-2">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            <div class="col-sm-12 col-md-8">
                <?php if($services->isEmpty()): ?>
                    <div class="alert alert-primary">
                        <i class="bi bi-exclamation-circle"></i> You haven't applied for any services
                    </div>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Service</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img src="/storage/<?php echo e($service->car->photo); ?>" class="img-fluid"
                                            alt="<?php echo e($service->car->name); ?>" width="300"><br>
                                        <b>Vehicle <?php echo e($service->car->name); ?> (<?php echo e($service->car->color); ?>)</b>
                                        <p>Service description: <br><?php echo e($service->service_description); ?></p>
                                    </td>
                                    <td>
                                        <?php if($service->status): ?>
                                            <p class="text-success">Completed</p>
                                        <?php else: ?>
                                            <p class="text-warning">Pending</p>
                                            <?php echo e($service->emp_id !== null ? 'Currently assigned to ' . $service->employee->name : ''); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                            data-bs-target="#delete-<?php echo e($service->id); ?>">
                                            Cancel
                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="delete-<?php echo e($service->id); ?>" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Cancel
                                                        </h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p class="text-danger">Are you sure you want to cancel this
                                                            appointment?</p><br>
                                                        <div class="alert alert-danger">
                                                            Vehicle: <?php echo e($service->car->name); ?>

                                                            (<?php echo e($service->car->color); ?>)
                                                            <br>
                                                            Description: <?php echo e($service->service_description); ?>

                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>
                                                        <form action="<?php echo e(route('services.destroy', $service->id)); ?>"
                                                            method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="btn btn-danger">Confirm</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mriganka/laravel/toyota-one-stop-platform/resources/views/user/service.blade.php ENDPATH**/ ?>