<?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-12">
                <div class="card shadow border-0">
                    <div class="card-body">
                        <h6 class="display-6">Customer List</h6>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Customer Details</th>
                                    <th>Vehicle</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <b>User: <?php echo e($transaction->user->name); ?>

                                                (<?php echo e($transaction->user->email); ?>)
                                            </b><br>
                                        </td>
                                        <td>
                                            Vehicle: <?php echo e($transaction->car->name); ?><br>
                                            <img src="/storage/<?php echo e($transaction->car->photo); ?>"
                                                alt="<?php echo e($transaction->car->name); ?>" class="img-fluid" width="250">
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($transactions->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mriganka/laravel/toyota-one-stop-platform/resources/views/admin/car_transaction.blade.php ENDPATH**/ ?>