<?php echo $__env->make('user.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5 pt-5 pb-5 shadow bg-white px-5">
        <div class="row">
            <div class="col-12">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->all()): ?>
                    <ul class="alert alert-danger mt-2">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
            <div class="col-sm-12 col-md-6">
                <img src="/storage/<?php echo e($car->photo); ?>" alt="<?php echo e($car->name); ?>" class="img-fluid">
                <?php if($car->feedbacks->isEmpty()): ?>
                    <p>No rating posted for this car</p>
                <?php else: ?>
                    <h4>User reviews</h4>
                    <?php $__currentLoopData = $car->feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card mt-2">
                            <div class="card-body">
                                <b><i class="bi bi-person-circle"></i> <?php echo e($feedback->user->email); ?></b>
                                <h6></h6>
                                <p>
                                    <span class="badge text-bg-secondary">
                                        <?php echo e($feedback->rating); ?>

                                        <i class="bi bi-star-fill"></i>
                                    </span>
                                    <?php echo e($feedback->message); ?>

                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="col-sm-12 col-md-6">
                <h1 class="display-3"><?php echo e($car->name); ?> </h1>
                <h4 class="text-secondary"><?php echo e($car->color); ?></h4>
                <br>
                <p class="fs-3 text-danger">$ <?php echo e($car->price); ?></p>
                <b>Built-model: <?php echo e($car->year); ?></b>
                <p><?php echo e($car->description); ?></p>

                <?php if($car->stock > 0): ?>
                    <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#addToCart">
                        Add to cart
                    </button>

                    <div class="modal fade" id="addToCart" tabindex="-1" aria-labelledby="addToCartLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="addToCartLabel">Add to cart</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <h1 class="display-3"><?php echo e($car->name); ?></h1>
                                    <h4 class="text-secondary"><?php echo e($car->color); ?></h4>
                                    <p>Add these to cart?</p>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                                    <form action="<?php echo e(route('user.cart', $car->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-dark">Yes</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <button disabled="disabled" class="btn btn-dark">Add to cart</button>
                    <p class="text-danger">This vehicle is out of stock</p>
                <?php endif; ?>
                <!-- Button trigger modal -->

                <!-- Modal -->

                <?php if(auth()->user()->cars->contains($car->id)): ?>
                    <div class="col-sm-12 col-md-6 mt-5">
                        <div class="card bg-light">
                            <div class="card-body">
                                <form action="<?php echo e(route('user.feedback', $car->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <h4>Add your feed back</h4>
                                    <label for="rating">Rating</label>
                                    <input type="number" name="rating" class="form-control mt-2" id="rating"
                                        min="1" max="5">
                                    <label for="message">Your message</label>
                                    <textarea name="message" class="form-control mt-2" id="message" cols="10" rows="3"
                                        placeholder="Your message"></textarea>
                                    <button type="submit" class="btn btn-dark mt-3">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mriganka/laravel/toyota-one-stop-platform/resources/views/user/carpage.blade.php ENDPATH**/ ?>