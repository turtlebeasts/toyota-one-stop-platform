<?php echo $__env->make('admin.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container mt-5 pt-5 pb-5 shadow bg-white px-5">
        <div class="row">
            <div class="col-12">
                <h3>Applied services</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if($errors->all()): ?>
                    <ul class="alert alert-danger mt-2">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
                <?php if($services->isEmpty()): ?>
                    <div class="alert alert-primary">
                        <i class="bi bi-exclamation-circle"></i> No services till now
                    </div>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Service</th>
                                <th>Status</th>
                                <th>Assign</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img src="/storage/<?php echo e($service->car->photo); ?>" class="img-fluid"
                                            alt="<?php echo e($service->car->name); ?>" width="300"><br>
                                        <b>Vehicle <?php echo e($service->car->name); ?> (<?php echo e($service->car->color); ?>)</b>
                                        <p>Service description: <br><?php echo e($service->service_description); ?></p>
                                        <b>User: <?php echo e($service->user->email); ?> (<?php echo e($service->user->name); ?>)</b>
                                    </td>
                                    <td>
                                        <?php if($service->status): ?>
                                            <p class="text-success">Completed</p>
                                        <?php else: ?>
                                            <p class="text-warning">Pending</p>
                                            <?php echo e($service->emp_id !== null ? 'Currently assigned to ' . $service->employee->name : ''); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-dark" data-bs-toggle="modal"
                                            data-bs-target="#delete-<?php echo e($service->id); ?>">
                                            <i class="bi bi-person-circle"></i>
                                            <?php echo e($service->emp_id == null ? 'Assign' : 'Re-assign'); ?>

                                        </button>

                                        <!-- Modal -->
                                        <div class="modal fade" id="delete-<?php echo e($service->id); ?>" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Assign task
                                                        </h1>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                            aria-label="Close"></button>
                                                    </div>
                                                    <form action="<?php echo e(route('admin.services.assign', $service->id)); ?>"
                                                        method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PUT'); ?>
                                                        <div class="modal-body">
                                                            <h6>
                                                                <?php echo e($service->emp_id == null ? 'Assign task' : 'Re-assign task'); ?>

                                                                to
                                                            </h6>

                                                            <select name="emp_id" class="form-control">
                                                                <option value="">-SELECT-</option>
                                                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($e->id); ?>">
                                                                        <?php echo e($e->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>

                                                            <?php echo e($service->emp_id !== null ? 'Currently assigned to ' . $service->employee->name : ''); ?>

                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-bs-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-dark">Confirm</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mriganka/laravel/toyota-one-stop-platform/resources/views/admin/service.blade.php ENDPATH**/ ?>