<?php echo $__env->make('user.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container bg-light mt-5 py-5">
        <div class="row">
            <div class="col-12">
                <h3>Your cart</h3>
                <?php if(session('delete')): ?>
                    <div class="alert alert-danger"><?php echo e(session('delete')); ?></div>
                <?php endif; ?>
                <?php if($cart->isEmpty()): ?>
                    <div class="alert alert-primary">
                        <i class="bi bi-exclamation-circle"></i> Your cart is empty
                    </div>
                <?php else: ?>
                    <div class="alert alert-primary">
                        Total cart items: <?php echo e(sizeof($cart)); ?><br>
                        <?php
                            $total = 0;
                            if (sizeof($cart) > 0) {
                                foreach ($cart as $key => $c) {
                                    $total += $c->car->price;
                                }
                                echo "Total price: $ " . $total;
                            }
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="row">
            <?php if($cart->isNotEmpty()): ?>
                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-12 col-md-3">
                        <div class="card">
                            <div class="card-body">
                                <h6><?php echo e($cart->car->name); ?></h6>
                                <img src="/storage/<?php echo e($cart->car->photo); ?>" alt="" class="img-fluid">
                                <b>$ <?php echo e($cart->car->price); ?></b><br>

                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-danger mt-2 btn-sm" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal-<?php echo e($cart->id); ?>">
                                    Remove item
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal-<?php echo e($cart->id); ?>" tabindex="-1"
                                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Remove Item</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                Are you sure you want to remove this item?<br>
                                                <img src="/storage/<?php echo e($cart->car->photo); ?>" alt="<?php echo e($cart->car->name); ?>"
                                                    class="img-fluid"><br>
                                                <b><?php echo e($cart->car->name); ?></b>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close</button>
                                                <form action="<?php echo e(route('cart.remove', $cart->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger">Confirm</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mriganka/laravel/toyota-one-stop-platform/resources/views/user/cart.blade.php ENDPATH**/ ?>